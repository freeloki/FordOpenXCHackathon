var REST_API_URL = "https://api.ardich.com/api/v3";

var USERNAME = /* IoT Ignite Account Username */; 
var PASSWORD = /* IoT Ignite Account Password */; 

var DEVICE_ID = /* Your device id licensed in IoT Ignite Platform */;

var NODE_ID = "Ford";
var SPEED_SENSOR_ID = "SpeedThing";
var RPM_SENSOR_ID = "RPMThing";
var LOCATION_SENSOR_ID = "LocationThing";
var EMERGENCY_SENSOR_ID = "EmergencyCallThing";

var accessToken;

var speedGauge = createSpeedGauge();
var rpmGauge = createRPMGauge();

var lastLocation;

setTimeout(function() {
    $.ajax({
        url: REST_API_URL + "/login/oauth",
        type: 'POST',
        data: {"grant_type": "password", "username": USERNAME, "password": PASSWORD},
        dataType: 'json',
        headers: {'Authorization': 'Basic ZnJvbnRlbmQ6', 'Content-Type': 'application/x-www-form-urlencoded'}
    }).done(function(data) {
        if (data.hasOwnProperty('access_token')) {
            accessToken = data.access_token;

            getRPM();
            getSpeed();
            getLocation();
            openSocketConnection();
        }
    }).fail(function(error) {
        $('#message').html('<label style="color: red;">' + error.responseJSON.error_description + '</label>');
    });
}, 2000);

var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 3,
    center: new google.maps.LatLng( 38.963745 , 35.243322), // centered TR
});

var marker;

function getSpeed() {
    $.ajax({
        url: REST_API_URL + '/device/' + DEVICE_ID + '/sensor-data?nodeId=' + NODE_ID + '&sensorId=' + SPEED_SENSOR_ID,
        type: 'GET',
        data: {},
        dataType: 'json',
        headers: {
            'Authorization': 'Bearer ' + accessToken,
            'Content-Type': 'application/json'
        }
    }).done(function (result) {
        var value = JSON.parse(result.data.data)[0];lastLocation
        
        setGaugeValue(speedGauge, value);
        $('#speed-value').text(parseInt(value));
    }).fail(function (error) {
        $('#message').html('<label style="color: red;">' + error.responseJSON.message + '</label>');
    });

}

function getRPM() {
    $.ajax({
        url: REST_API_URL + '/device/' + DEVICE_ID + '/sensor-data?nodeId=' + NODE_ID + '&sensorId=' + RPM_SENSOR_ID,
        type: 'GET',
        data: {},
        dataType: 'json',
        headers: {
            'Authorization': 'Bearer ' + accessToken,
            'Content-Type': 'application/json'
        }
    }).done(function (result) {
        var value = JSON.parse(result.data.data)[0];
        
        setGaugeValue(rpmGauge, value);
        $('#rpm-value').text(parseInt(value));
    }).fail(function (error) {
        $('#message').html('<label style="color: red;">' + error.responseJSON.message + '</label>');
    });

}

function getLocation() {
    $.ajax({
        url: REST_API_URL + '/device/' + DEVICE_ID + '/sensor-data?nodeId=' + NODE_ID + '&sensorId=' + LOCATION_SENSOR_ID,
        type: 'GET',
        data: {},
        dataType: 'json',
        headers: {
            'Authorization': 'Bearer ' + accessToken,
            'Content-Type': 'application/json'
        }
    }).done(function (result) {
        var value = JSON.parse(result.data.data)[0];
        
        setNewLocation(value);
    }).fail(function (error) {
        $('#message').html('<label style="color: red;">' + error.responseJSON.message + '</label>');
    });

}

function setNewLocation(value) {
    var location = JSON.parse(value);
    
    lastLocation = value;
    
    if(marker) {
        marker.setPosition(new google.maps.LatLng(location.latitude, location.longitude));
    } else {
        marker = new google.maps.Marker({
            position: new google.maps.LatLng(location.latitude, location.longitude),
            map: map
        });
    }
    
    map.setCenter(marker.getPosition());
    map.setZoom(15);
}

function setGaugeValue(gaugeChart, value) {
  if ( gaugeChart ) {
    if ( gaugeChart.arrows ) {
      if ( gaugeChart.arrows[ 0 ] ) {
        if ( gaugeChart.arrows[ 0 ].setValue ) {
          gaugeChart.arrows[ 0 ].setValue( value );
        }
      }
    }
  }
}

function createSpeedGauge() {
    return AmCharts.makeChart('speed-gauge', {
          "type": "gauge",
          "theme": "dark",
          "axes": [ {
            "axisThickness": 1,
            "axisAlpha": 0.2,
            "tickAlpha": 0.2,
            "valueInterval": 20,
            "bands": [ {
              "color": "#84b761",
              "endValue": 90,
              "startValue": 0
            }, {
              "color": "#fdd400",
              "endValue": 130,
              "startValue": 90
            }, {
              "color": "#cc4748",
              "endValue": 220,
              "innerRadius": "88%",
              "startValue": 130
            } ],
            "bottomText": "km/h",
            "bottomTextYOffset": -20,
            "endValue": 220
          } ],
          "arrows": [ {} ]
        } );
}

function createRPMGauge() {
    return AmCharts.makeChart('rpm-gauge', {
          "type": "gauge",
          "theme": "dark",
          "axes": [ {
            "axisThickness": 1,
            "axisAlpha": 0.2,
            "tickAlpha": 0.2,
            "valueInterval": 500,
            "bands": [ {
              "color": "#d1d1e0",
              "endValue": 5000,
              "startValue": 0
            }, {
              "color": "#cc4748",
              "endValue": 6000,
              "innerRadius": "88%",
              "startValue": 5000
            } ],
            "bottomText": "RPM",
            "bottomTextYOffset": -20,
            "endValue": 6000
          } ],
          "arrows": [ {} ]
        } );
}

/*** WEB SOCKET BEGIN ***/

var ws;

function openSocketConnection() {
    $('.open-socket').hide();
    $('.close-socket').show();
    
    $.ajax({
        url: REST_API_URL + '/subscribe/device/token',
        type: 'GET',
        data: {
            device: DEVICE_ID
        },
        dataType: 'json',
        headers: {
            'Authorization': 'Bearer ' + accessToken,
            'Content-Type': 'application/json'
        }
    }).done(function (result) {
        var subscribeId = result.id;
        var subscribeUrl = result.url;
        var subscribeToken = result.token;

        ws = new WebSocket(subscribeUrl);

        ws.onopen = function () {
            var subscribeMessage = new Object();
            subscribeMessage.deviceId = DEVICE_ID;
            subscribeMessage.nodeId = NODE_ID;
            //subscribeMessage.sensorId = LED_SENSOR_ID;
            subscribeMessage.id = subscribeId;
            subscribeMessage.version = "2.0";
            subscribeMessage.token = subscribeToken;

            var subscribe = new Object();
            subscribe.type = "subscribe";
            subscribe.message = subscribeMessage;

            ws.send(JSON.stringify(subscribe));
        };

        ws.onmessage = function (event) {
            var response = JSON.parse(event.data);

            if (response.header.type == "Success") {
                //$('#message').html('<label style="color: green;">Subscribed</label>');
            } else if (response.header.type == "UnAuthorized") {
                //$('#message').html('<label style="color: red;">Subscription Failed</label>');
            } else if (response.header.type == "DeviceInfo") {
                var value = response.body.extras.sensorData[0].values[0];
                
                var sensorId = response.body.sensorId;
                
                if(sensorId === SPEED_SENSOR_ID) {
                    setGaugeValue(speedGauge, value);
                     $('#speed-value').text(parseInt(value));
                } else if(sensorId === RPM_SENSOR_ID) {
                    setGaugeValue(rpmGauge, value);
                     $('#rpm-value').text(parseInt(value));
                } else if(sensorId === LOCATION_SENSOR_ID) {
                    setNewLocation(value);
                } else if(sensorId === EMERGENCY_SENSOR_ID) {
                    if(typeof Android === "undefined") {
                        alert("Emergency call is only available on Android !!");
                    } else {
                        Android.emergencyCall(lastLocation);
                    }
                }
            }
        }

        ws.onclose = function () {
            setTimeout(function() {
                openSocketConnection();
            }, 1000);
        }
    }).fail(function (error) {
        $('#message').html('<label style="color: red;">' + error.responseJSON.message + '</label>');
    });
}

function closeSocketConnection() {
    if (ws) {
        ws.close();
    }
}

/*** WEB SOCKET END ***/

$('#refreshPage').click(function() {
    if(typeof Android === "undefined") {
        window.location.reload(); 
    } else {
        Android.emergencyCall(lastLocation);
    }
});
